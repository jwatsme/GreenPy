"""
Program: WannerJoshFinalProject.py
Author: Josh Wanner
Last date modified: 12/14/2021

GreenPy

1. Signigicant constants
    
    
2. The inputs are
    temperature
    humidity
    pH
    Light Level
    
3. Computations:
    
    
4. The outputs are
   placement of arrows on gauges  
    
"""
# bringing in necessary external modules
import tkinter as tk
from tkinter import *
from tkinter import ttk
from datetime import datetime
from datetime import date

# creating main window
window = tk.Tk()
window.title("GreenPy")
window.geometry("1300x425")

# setting date
today = date.today()
todayFmt = today.strftime("%d/%m/%Y")

# initializing global variables
temperature = tk.DoubleVar()
lblTemp = temperature.get()
lblHumd = 0
lblPH = 0
lblLight = ""
arrowTemp = 150
arrowHumd = 150
arrowPH = 150
arrowLight = 60

        
#clock function
def clock():
    now = datetime.now()
    currentTime = now.strftime("%H:%M:%S")
    lblTime.config(text = currentTime)
    lblTime.after(1000, clock)

# button functions
def chgMeasurement():
    if btnMeasurement['text'] == "Celsius":
        btnMeasurement['text'] = "Fahrenheit"
    else:
        btnMeasurement['text'] = "Celsius"
def exitWindow():
    window.destroy()

# Creates Top Level Environment window  
def openEnvironmentWindow():

    # Creates Top Level button functions 
    def clrEnvironment():
        entTemp.delete(0, END)
        entHumd.delete(0, END)
        entPH.delete(0, END)
        entLight.delete(0, END)

    def saveEnvironment():
        global lblTemp
        lblTemp = temperature.get()
        print(lblTemp)
                
    def exitEnvironment():
        environmentWindow.destroy()   
    
    environmentWindow = tk.Toplevel(window)
    environmentWindow.title("Environmental Parameters")
    environmentWindow.geometry("335x210")
    lblenvironmentWindow = tk.Label(environmentWindow, text = "Environmental Parameters")
    
    # Environment window buttons
    btnClear = tk.Button(environmentWindow,
    text = "Clear",
    command = clrEnvironment,
    width = 10,
    height = 2,
    bg = "blue",
    fg = "yellow"
    )

    btnSave = tk.Button(environmentWindow,
    text = "Save",
    command = saveEnvironment,
    width = 10,
    height = 2,
    bg = "blue",
    fg = "yellow"
    )

    btnExit = tk.Button(environmentWindow,
    text = "Exit",
    command = exitEnvironment,
    width = 10,
    height = 2,
    bg = "blue",
    fg = "yellow"
    )
        
# Text entry widgets in Environment window with labels
    entlblTemp = tk.Label(environmentWindow, text = "Temperature")  
    entTemp = tk.Entry(environmentWindow, textvariable = temperature, width = 35)
    entTemp.insert(END, "... " + btnMeasurement['text'] + " degrees...") # Default value for entry changes base on system choice
    entlblHumd = tk.Label(environmentWindow, text = "Humidity")
    entHumd = tk.Entry(environmentWindow, width = 35)
    entHumd.insert(END, "Percentage...") # Default value for entry
    entlblPH = tk.Label(environmentWindow, text = "pH")
    entPH = tk.Entry(environmentWindow, width = 35)
    entPH.insert(END, "Value between 0-14...") # Default value for entry
    entlblLight = tk.Label(environmentWindow, text = "Light Level")
    entLight = ttk.Combobox(environmentWindow, values = ["Dark", "Partial Light", "Full Light"], width = 35)
    entLight.insert(END, "Choose from list...") # Default value for entry

# Placing widgets in Environment window
    lblenvironmentWindow.grid(row = 0, column = 1, padx = 5, pady = 5)
    entlblTemp.grid(row = 1, column = 0, padx = 5, pady = 5)
    entTemp.grid(row = 1, column = 1, columnspan = 2, padx = 5, pady = 5)
    entlblHumd.grid(row = 2, column = 0, padx = 5, pady = 5)
    entHumd.grid(row = 2, column = 1, columnspan = 2, padx = 5, pady = 5)
    entlblPH.grid(row = 3, column = 0, padx = 5, pady = 5)
    entPH.grid(row = 3, column = 1, columnspan = 2, padx = 5, pady = 5)
    entlblLight.grid(row = 4, column = 0, padx = 5, pady = 5)
    entLight.grid(row = 4, column = 1, columnspan = 2, padx = 5, pady = 5)
    btnClear.grid(row = 5, column = 0, padx = 5, pady = 5)
    btnSave.grid(row = 5, column = 1, padx = 5, pady = 5)
    btnExit.grid(row = 5, column = 2, padx = 5, pady = 5)

# Calculating positions of arrows
lblTemp = temperature.get()

if lblTemp >= 65 and lblTemp <= 75:
    arrowTemp = 150
elif lblTemp < 65 and lblTemp >= 59:
    arrowTemp = 115
elif lblTemp < 59:
    arrowTemp = 30
elif lblTemp > 75 and lblTemp <= 81:
    arrowTemp = 185
elif lblTemp > 81:
    arrowTemp = 270
else:
    lblTemp = "Error" 

if lblHumd >= 65 and lblHumd <= 75:
    arrowHumd = 150
elif lblHumd < 65 and lblHumd >= 59:
    arrowHumd = 115
elif lblHumd < 59:
    arrowHumd = 30
elif lblHumd > 75 and lblHumd <= 81:
    arrowHumd = 185
elif lblHumd > 81:
    arrowHumd = 270
else:
    lblHumd = "Error"

if lblPH >= 6.2 and lblPH <= 6.8:
    arrowPH = 150
elif lblPH < 6.2 and lblPH <= 6.0:
    arrowPH = 115
elif lblPH < 6.0:
    arrowPH = 30
elif lblPH > 6.8 and lblPH <= 7.0:
    arrowPH = 185
elif lblPH > 7.0:
    arrowPH = 270
else:
    lblPH = "Error"

if lblLight == "Full Light":
    arrowLight = 60
elif lblLight == "Partial Light":
    arrowLight = 150
elif lblLight == "Dark":
    arrowLight = 240
else:
    lblLight = "Error"


# Main window labels
lblTitle = tk.Label(
    text = "GreenPy",
    font = 25,
    fg = "white",
    bg = "#3CD812",
    width = 40,
    height = 5,
)

lblTime = tk.Label(
    fg = "white",
    bg = "#3CD812",
    width = 15,
    height = 2,
)

lblDate = tk.Label(
    text = todayFmt,
    fg = "white",
    bg = "#3CD812",
    width = 15,
    height = 2,
)

lblTemperature = tk.Label(
    text = "Temperature",
    fg = "white",
    bg = "#3CD812",
    width = 35,
    height = 2,
)

lblHumidity = tk.Label(
    text = "Humidity",
    fg = "white",
    bg = "#3CD812",
    width = 35,
    height = 2,
)

lblWindSpeed = tk.Label(
    text = "pH",
    fg = "white",
    bg = "#3CD812",
    width = 35,
    height = 2,
)

lblLightLevel = tk.Label(
    text = "Light Level",
    fg = "white",
    bg = "#3CD812",
    width = 35,
    height = 2,
)

lblCnvTemp = tk.Label(
    text = str(lblTemp) + u"\N{DEGREE SIGN}",
    width = 15,
    height = 2,
    fg = 'white',
    bg = '#3CD812',
)


lblCnvHum = tk.Label(
    text = str(lblHumd) + "%",
    width = 15,
    height = 2,
    fg = 'white',
    bg = '#3CD812',
)

lblCnvPH = tk.Label(
    text = str(lblPH),
    width = 15,
    height = 2,
    fg = 'white',
    bg = '#3CD812',
)

lblCnvLight = tk.Label(
    text = str(lblLight),
    width = 15,
    height = 2,
    fg = 'white',
    bg = '#3CD812',
)

# Main window buttons
btnMeasurement = tk.Button(window,
    text= "Fahrenheit",
    command = chgMeasurement,
    width = 15,
    height = 2,
    bg = "blue",
    fg = "yellow"
)

btnExit = tk.Button(window,
    text = "Exit",
    command = exitWindow,
    width = 15,
    height = 2,
    bg = "blue",
    fg = "yellow",
)

btnEnvironment = tk.Button(window,
    text = "Environment",
    command = openEnvironmentWindow,
    width = 15,
    height = 2,
    bg = "blue",
    fg = "yellow",
)


# Gauges

# Temperature Gauge
cnvTemperature = tk.Canvas(bg ="blue", height = 140, width = 300)

coord = 20, 50, 280, 210

arcTempAlt2 = cnvTemperature.create_arc(coord, start = 144, extent = 36, fill = "red")

arcTempAlt1 = cnvTemperature.create_arc(coord, start= 0, extent = 36, fill = "red")

arcTempWrn1 = cnvTemperature.create_arc(coord, start = 108, extent = 36, fill = "yellow")

arcTempWrn2 = cnvTemperature.create_arc(coord, start = 36, extent = 36, fill = "yellow")

arcTempOpt = cnvTemperature.create_arc(coord, start = 72, extent = 36, fill = "green")

cnvTemperature.create_line(arrowTemp, 100, 150, 130, width = 3, arrow = FIRST)

# Humidity Gauge
cnvHumidity = tk.Canvas(bg ="blue", height = 140, width = 300)

coord = 20, 50, 280, 210

arcHumAlt2 = cnvHumidity.create_arc(coord, start = 144, extent = 36, fill = "red")

arcHumAlt1 = cnvHumidity.create_arc(coord, start= 0, extent = 36, fill = "red")

arcHumWrn1 = cnvHumidity.create_arc(coord, start = 108, extent = 36, fill = "yellow")

arcHumWrn2 = cnvHumidity.create_arc(coord, start = 36, extent = 36, fill = "yellow")

arcHumOpt = cnvHumidity.create_arc(coord, start = 72, extent = 36, fill = "green")

cnvHumidity.create_line(arrowHumd, 100, 150, 130, width = 3, arrow = FIRST)

# ph Gauge
cnvPH = tk.Canvas(bg ="blue", height = 140, width = 300)

coord = 20, 50, 280, 210

arcPHAlt2 = cnvPH.create_arc(coord, start = 144, extent = 36, fill = "red")

arcPHAlt1 = cnvPH.create_arc(coord, start= 0, extent = 36, fill = "red")

arcPHWrn1 = cnvPH.create_arc(coord, start = 108, extent = 36, fill = "yellow")

arcPHWrn2 = cnvPH.create_arc(coord, start = 36, extent = 36, fill = "yellow")

arcPHOpt = cnvPH.create_arc(coord, start = 72, extent = 36, fill = "green")

cnvPH.create_line(arrowPH, 100, 150, 130, width = 3, arrow = FIRST)

# Light Level Gauge
cnvLightLevel = tk.Canvas(bg ="blue", height = 140, width = 300)

coord = 20, 50, 280, 210

arcLightAlt1 = cnvLightLevel.create_arc(coord, start= 0, extent = 60, fill = "red")

arcLightWrn1 = cnvLightLevel.create_arc(coord, start = 60, extent = 60, fill = "yellow")

arcLightOpt = cnvLightLevel.create_arc(coord, start = 120, extent = 60, fill = "green")

cnvLightLevel.create_line(arrowLight, 100, 150, 130, width = 3, arrow = FIRST)


# Places main window widgets
lblTitle.grid(row = 0, column = 1, columnspan = 2, pady = 5)

lblTime.grid(row = 0, column = 0, pady = 5)

lblDate.grid(row = 0, column = 3, pady = 5)

lblTemperature.grid(row = 2, column = 0, padx = 5, pady = 5)

lblHumidity.grid(row = 2, column = 1, padx = 5, pady = 5)

lblWindSpeed.grid(row = 2, column = 2, padx = 5, pady = 5)

lblLightLevel.grid(row = 2, column = 3, padx = 5, pady = 5)

btnMeasurement.grid(row = 1, column = 0, columnspan = 2, pady = 10)

btnExit.grid(row = 1, column = 2, columnspan = 2, pady = 10)

btnEnvironment.grid(row = 1, column = 1, columnspan = 2, pady = 10)

cnvTemperature.grid(row = 3, column = 0, padx = 10, pady = 10)

cnvHumidity.grid(row = 3, column = 1, padx = 10, pady = 10)

cnvPH.grid(row = 3, column = 2, padx = 10, pady = 10)

cnvLightLevel.grid(row = 3, column = 3, padx = 10, pady = 10)

lblCnvTemp.grid(row = 4, column = 0, padx = 5, pady = 5)

lblCnvHum.grid(row = 4, column = 1, padx = 5, pady = 5)

lblCnvPH.grid(row = 4, column = 2, padx = 5, pady = 5)

lblCnvLight.grid(row = 4, column = 3, padx = 5, pady = 5)


# Program exit
clock()

window.mainloop()
